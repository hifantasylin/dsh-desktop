/**
 * Landing media into the user's asset tree (`<assetsRoot>/<project>/…`).
 *
 * The single source of truth for where an asset goes and what its index row says.
 * The `media_asset_save` tool and the OpenAI facade both land through here, so a
 * file saved by an agent turn and one saved by a canvas run cannot disagree about
 * path rules, categories, or the index format.
 *
 * Path rules, inherited from the tool: `name` and `dir` are relative sub-paths
 * under `<assetsRoot>/<project>/`; a `..` segment, a drive letter or a
 * leading slash is refused rather than sanitized, because a caller that tries to
 * escape the tree is not a caller whose intent we should guess.
 *
 * @module @roubaai/media/asset-landing
 */
/** Asset categories the tools and the settings page agree on. */
export declare const ASSET_CATEGORIES: readonly ["upload", "character", "scene", "prop", "keyframe", "video", "storyboard", "cover", "meta"];
/** One asset category. */
export type AssetCategory = (typeof ASSET_CATEGORIES)[number];
/**
 * Whether a string names a supported asset category.
 * @param value - the candidate category.
 * @returns true when the value is one of {@link ASSET_CATEGORIES}.
 */
export declare function isAssetCategory(value: string): value is AssetCategory;
/** One landing request: where the bytes go and how the index describes them. */
export interface LandRequest {
    /** The asset root; the project directory is a child of it. */
    readonly assetsRoot: string;
    /** Project folder name under `.assets/`. */
    readonly project: string;
    /** Sub-directory under the project, e.g. `01_角色/CH001_花十/02_定稿图`. */
    readonly dir: string;
    /** Friendly file base name, without extension; may carry `/` sub-paths. */
    readonly name: string;
    /** File extension without the dot (`png`, `jpg`, `mp4`). */
    readonly ext: string;
    /** The bytes to write. */
    readonly bytes: Uint8Array;
    /** Index category. */
    readonly category: string;
    /** The reference the caller was given, recorded verbatim in the index. */
    readonly reference: string;
    /** Public URL the bytes came from, when one exists. */
    readonly url?: string | undefined;
    /** Same-origin URL to register these bytes under, when one exists. */
    readonly displayUrl?: string | undefined;
}
/** Where one asset landed. */
export interface LandedAsset {
    /** Absolute path of the written file. */
    readonly path: string;
    /** Path relative to `.assets/`, using `/` separators. */
    readonly relative: string;
    /** Bytes written. */
    readonly bytes: number;
}
/**
 * Resolve the absolute file path one asset will be written to.
 * @param options - the landing request (bytes are not needed to resolve a path).
 * @param tool - the caller's name, used in error messages.
 * @returns the file path plus the sanitized name, directory and project root.
 */
export declare function resolveLandingPath(options: Pick<LandRequest, 'assetsRoot' | 'project' | 'dir' | 'name' | 'ext'>, tool?: string): {
    filePath: string;
    projectDir: string;
    safeName: string;
    safeDir: string;
};
/** Append one line to the project asset index (writes the header on first use). */
export declare function appendIndex(assetsDir: string, entry: {
    category: string;
    name: string;
    path: string;
    ref: string;
    url: string | undefined;
    ts: number;
    mediaType: string;
}): Promise<void>;
/**
 * Write one media file into the asset tree and record it in the project index.
 * @param request - the bytes, their destination and their index description.
 * @returns where the file landed and how many bytes were written.
 */
export declare function landMediaAsset(request: LandRequest): Promise<LandedAsset>;
/** MIME for a saved file extension (media cache registration + asset index). */
export declare function mediaMimeOf(ext: string): string;
//# sourceMappingURL=asset-landing.d.ts.map