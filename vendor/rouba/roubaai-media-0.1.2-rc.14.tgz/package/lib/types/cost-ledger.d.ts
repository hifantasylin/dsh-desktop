/**
 * Media cost ledger — automatic, append-only per-completion record of media
 * generation cost. The `generate_image` / `generate_video` / `generate_music`
 * tools write one line per completed job themselves, so cost tracking is
 * reliable even when the agent forgets to record it. The ledger lives at
 * `<workspace>/.assets/media-cost.jsonl` (one JSON object per line); the
 * `media_cost_summary` tool folds it into an owner/model-readable total and
 * drives the cost-tracker document's actual-vs-expected comparison.
 *
 * @module @roubaai/media/cost-ledger
 */
/** One ledger line, written on every media job completion. */
export interface MediaCostEntry {
    /** Completion timestamp (ms). */
    ts: number;
    tool: 'image' | 'video' | 'music';
    model: string;
    /** LLM-provided project name (奇幻超人); falls back to the workspace when absent. */
    project: string;
    /** LLM-provided shot identifier (EP01_镜02_镇民躲藏); drives retry detection. */
    label?: string;
    /** Readable spec: image resolution | video duration×resolution | music duration. */
    spec: string;
    /** USD cost; provider-reported for video, estimated from the rate table otherwise. */
    costUsd: number;
    /** reported = provider returned a real cost; estimated = rate-table lookup. */
    source: 'reported' | 'estimated';
    taskId?: string;
    /** Same (project, label) already present in the ledger => this is a retry. */
    retry: boolean;
}
/**
 * Ledger file for one project: `<assetsRoot>/<project>/media-cost.jsonl`.
 * A missing project — or one that is actually an absolute path, which no project
 * name is — falls back to `<assetsRoot>/default/media-cost.jsonl`, so a run that
 * names no project still records its cost under `default` rather than under a
 * mangled absolute-path directory.
 * @param assetsRoot - the asset root, resolved by `asset-root`.
 * @param project - the project folder name, or undefined for the default.
 * @returns the absolute ledger path.
 */
export declare function ledgerPath(assetsRoot: string, project: string | undefined): string;
/** The project a run without one is recorded under. */
export declare const DEFAULT_PROJECT = "default";
/**
 * True when the same (project, label) already exists in the ledger.
 * @param assetsRoot - the asset root.
 * @param project - the project folder name.
 * @param label - the run label, when the caller gave one.
 * @returns whether this exact run already happened.
 */
export declare function isRetry(assetsRoot: string, project: string, label: string | undefined): Promise<boolean>;
/**
 * Append one completion record; `retry` is computed automatically.
 * @param assetsRoot - the asset root.
 * @param entry - the record, without its computed `retry` flag.
 * @returns the complete record.
 */
export declare function appendMediaCost(assetsRoot: string, entry: Omit<MediaCostEntry, 'retry'>): Promise<MediaCostEntry>;
/**
 * Read ledger entries. With a project, reads only that project's file
 * (`<assetsRoot>/<project>/media-cost.jsonl`); without one, scans every project
 * directory under the asset root (including `default`) so a user-wide summary
 * folds all projects together.
 * @param assetsRoot - the asset root.
 * @param project - the project folder name, or undefined for every project.
 * @returns the recorded entries.
 */
export declare function readLedger(assetsRoot: string, project?: string): Promise<MediaCostEntry[]>;
/** A per-label fold: first cost, retry count, total cost. */
export interface LabelCost {
    project: string;
    label: string;
    firstUsd: number;
    retries: number;
    totalUsd: number;
    lastTs: number;
}
/** Cost summary folded from the ledger, optionally filtered by project / since. */
export interface MediaCostSummary {
    totalUsd: number;
    totalCount: number;
    retryCount: number;
    retryUsd: number;
    byLabel: LabelCost[];
    byTool: Array<{
        tool: MediaCostEntry['tool'];
        count: number;
        totalUsd: number;
    }>;
}
/**
 * Fold the ledger into a summary (newest label first).
 * @param assetsRoot - the asset root.
 * @param filter - optional project and time window.
 * @returns the folded summary.
 */
export declare function summarizeMediaCost(assetsRoot: string, filter?: {
    project?: string;
    since?: number;
}): Promise<MediaCostSummary>;
//# sourceMappingURL=cost-ledger.d.ts.map