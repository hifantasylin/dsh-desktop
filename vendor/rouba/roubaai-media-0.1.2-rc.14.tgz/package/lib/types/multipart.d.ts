/**
 * A minimal `multipart/form-data` reader.
 *
 * The canvas sends its video and image-edit requests as multipart bodies (the
 * OpenAI video shape posts `prompt`/`model`/`seconds`/`size` plus `image[]`
 * files), and this package carries no HTTP framework to parse them with. The
 * parser is deliberately small and strict: it understands one boundary, the
 * `name`/`filename`/`content-type` headers of a part, and refuses a body whose
 * framing does not match its declared boundary instead of guessing.
 *
 * @module @roubaai/media/multipart
 */
/** One decoded part of a multipart body. */
export interface MultipartPart {
    /** The form field name from `Content-Disposition`. */
    readonly name: string;
    /** The uploaded file name, when the part carries one. */
    readonly filename?: string;
    /** The part's own content type, when it declared one. */
    readonly contentType?: string;
    /** The raw part bytes. */
    readonly data: Buffer;
}
/**
 * The boundary declared by a `Content-Type` header.
 * @param contentType - the request's content-type header.
 * @returns the boundary, or undefined when the request is not multipart.
 */
export declare function boundaryOf(contentType: string | undefined): string | undefined;
/**
 * Decode a multipart body.
 * @param contentType - the request's content-type header (its boundary is used).
 * @param body - the whole request body.
 * @returns the decoded parts, in body order; an empty list when the body is not
 *   multipart or carries no part.
 */
export declare function parseMultipart(contentType: string | undefined, body: Buffer): MultipartPart[];
/**
 * The first part with the given field name, as text.
 * @param parts - decoded parts.
 * @param name - the field name to read.
 * @returns the trimmed value, or undefined when the field is absent or empty.
 */
export declare function textField(parts: readonly MultipartPart[], name: string): string | undefined;
/**
 * Every part with the given field name that carries a file.
 * @param parts - decoded parts.
 * @param name - the field name to read (matched with or without a `[]` suffix).
 * @returns the file parts, in body order.
 */
export declare function fileFields(parts: readonly MultipartPart[], name: string): MultipartPart[];
//# sourceMappingURL=multipart.d.ts.map