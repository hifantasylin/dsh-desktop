/**
 * OpenAI-compatible facade over the media registry.
 *
 * The canvas workbench talks to a generation backend as an OpenAI-compatible
 * channel: `POST <baseUrl>/v1/images/generations` for text-to-image, the
 * multipart `/v1/images/edits` for a reference edit, and `/v1/videos` with a
 * task poll for video. Serving those shapes from the harness host is what keeps
 * the provider key in the host process — the browser only ever holds a
 * same-origin URL — while the call still goes through the same provider registry
 * the agent tools use, so the backend that serves the agent also serves the
 * canvas.
 *
 * Paths are accepted with and without the `/v1` segment: a caller that appends
 * `/v1` to a base URL ending in `/openai` and one that does not must both land
 * here, and guessing which is a URL-shaped coin flip.
 *
 * What this module does NOT do yet, deliberately:
 * - the video task endpoints and the multipart edit body answer 501 with a
 *   stated reason instead of 404 (`unsupported` below), so a wrong URL and an
 *   unimplemented one stay distinguishable.
 *
 * A finished image is cached on the host and landed into
 * `<workspace>/.assets/<project>/<dir>/` with an index row and a cost-ledger
 * entry, exactly as a `generate_image` call would — the caller names the
 * destination with headers, and the defaults keep a canvas run self-describing
 * (`default/90_画布/canvas-<timestamp>`).
 *
 * @module @roubaai/media/openai-facade
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Context } from '@deepseek-ai/cordis';
import type { ImageGenerateInput, ImageGenerationResult } from './provider.ts';
/**
 * Route prefix on the host webserver.
 *
 * Deliberately a sibling of the media-cache prefix rather than a child of it:
 * the harness matches prefix routes in registration order, so a route registered
 * under `/api/roubaai-media/...` after the cache route never runs — the cache
 * answers first. A separate top-level prefix makes the two independent.
 */
export declare const OPENAI_FACADE_PREFIX = "/api/roubaai-openai";
/** Header naming the session a canvas run belongs to; the host resolves its workspace. */
export declare const SESSION_HEADER = "x-roubaai-session";
/** Header naming the project folder under the asset root. */
export declare const PROJECT_HEADER = "x-roubaai-project";
/** Header naming the landing sub-directory under the project. */
export declare const DIR_HEADER = "x-roubaai-dir";
/** Header naming the asset (extension added by the landing rules). */
export declare const NAME_HEADER = "x-roubaai-name";
/** Header naming the asset category. */
export declare const CATEGORY_HEADER = "x-roubaai-category";
/**
 * Translate an OpenAI image request into the provider seam's input.
 *
 * `size` is spelled `WxH` by the OpenAI shape and as a tier name by this
 * deployment's settings; both reach here, so a value that parses as pixels is
 * passed as pixels and anything else is left to the provider's own tier
 * validation. Nothing is invented for a field the caller omitted.
 * @param body - the parsed request body.
 * @returns the provider input plus the fields that were ignored.
 */
export declare function mapImageRequest(body: Record<string, unknown>): {
    input: ImageGenerateInput;
    ignored: string[];
};
/**
 * The URL the browser should load the finished image from.
 *
 * The provider's own result URL is a 24h CDN link, so a locally cached signed
 * stream is preferred when the bytes are already on disk; nothing here downloads
 * anything, which is why a run that has not been cached still answers with the
 * CDN URL rather than not answering at all.
 * @param result - the provider's result.
 * @returns the preferred URL, or undefined when the provider stated none.
 */
export declare function imageUrlOf(result: ImageGenerationResult): string | undefined;
/**
 * Answer one OpenAI-shaped request.
 * @param ctx - the plugin context (the media registry is read off it).
 * @param req - the incoming request.
 * @param res - the response to write.
 * @param url - the parsed request URL.
 */
export declare function handleOpenAiRequest(ctx: Context, req: IncomingMessage, res: ServerResponse, url: URL): Promise<void>;
/**
 * Register the facade on the host webserver.
 * @param ctx - the plugin context.
 * @returns the disposer removing the route.
 */
export declare function registerOpenAiRoutes(ctx: Context): () => void;
//# sourceMappingURL=openai-facade.d.ts.map