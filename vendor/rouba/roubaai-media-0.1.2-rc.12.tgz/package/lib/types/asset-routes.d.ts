/**
 * Routes over the asset trees: the session's workspace, plus mounted libraries.
 *
 * The canvas workbench is a browser app: it can display a URL, not a path. These
 * routes are what turn the asset trees into URLs — list a directory, list the
 * whole library, serve a file, accept an upload — so a canvas node can show an
 * image or a video straight out of `.assets` instead of importing a second copy
 * into browser storage, and the canvas' asset library can browse projects
 * without walking the filesystem from the browser.
 *
 * A request names the session it belongs to and the tree it addresses; the
 * session's workspace is resolved host-side (a caller-supplied path would make
 * these routes an arbitrary-file reader), and only the primary tree — the one
 * belonging to that workspace — accepts writes.
 *
 * Nothing outside a tree is reachable: every request path is resolved against
 * the named root and refused when it leaves that directory, so `..`, an absolute
 * path or a drive letter never reaches the filesystem. The listings answer with
 * relative paths only — an absolute path is the one thing the canvas
 * deliberately keeps out of anything it sends to a model, and these routes have
 * no reason to hand one out.
 *
 * @module @roubaai/media/asset-routes
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Context } from '@deepseek-ai/cordis';
export { primaryAssetsRoot, resolveInRoot, rootById, rootsForWorkspace } from './asset-root.ts';
export type { AssetRoot, AssetRoots } from './asset-root.ts';
/**
 * Route prefix on the host webserver.
 *
 * A sibling of the media-cache prefix, not a child: the harness matches prefix
 * routes in registration order, so a child of `/api/roubaai-media` registered
 * after the cache route is never reached.
 */
export declare const ASSETS_ROUTE_PREFIX = "/api/roubaai-assets";
type MediaKind = 'image' | 'video' | 'audio' | 'other';
/**
 * Resolve the workspace a request belongs to.
 *
 * Supplied by the composition, which owns the session lookup: a route that took
 * the path from its caller would read any file the host can read.
 * @param sessionId - the session the request named, when it named one.
 * @returns the session's working directory, or undefined when it is unknown.
 */
export type WorkspaceResolver = (sessionId: string | undefined) => Promise<string | undefined> | string | undefined;
/**
 * One byte range out of a `Range` header, when it is a single satisfiable range.
 * @param header - the raw header value.
 * @param size - the file size, for clamping and for the `*` form.
 * @returns the inclusive byte window, or undefined to send the whole file.
 */
export declare function parseRange(header: string | undefined, size: number): {
    start: number;
    end: number;
} | undefined;
/** One file as the library describes it. */
export interface LibraryFile {
    /** Tree the file belongs to. */
    readonly root: string;
    /** Path relative to that tree, `/` separators. */
    readonly path: string;
    /** File name including its extension. */
    readonly name: string;
    /** Owning project: the first directory under the tree. */
    readonly project: string;
    /** First directory below the project (`01_角色`, …), or `''` for a file filed directly in it. */
    readonly group: string;
    /** Media kind derived from the extension, so an unindexed file is still classified. */
    readonly kind: MediaKind;
    /** Bytes on disk. */
    readonly size: number;
    /** Last modification time in ms. */
    readonly mtime: number;
}
/** One project's rollup, for the library's project view. */
export interface LibraryProject {
    /** Tree the project belongs to. */
    readonly root: string;
    /** Directory name under the tree. */
    readonly name: string;
    /** Files the walk found (bookkeeping aside). */
    readonly files: number;
    /** Their total size. */
    readonly bytes: number;
    /** Newest file's mtime, or 0 for a project with none. */
    readonly updatedAt: number;
    /** Newest image, as a path to hand to the file route; undefined when it has none. */
    readonly cover: string | undefined;
}
/**
 * Answer one asset request.
 * @param req - the incoming request.
 * @param res - the response to write.
 * @param url - the parsed request URL.
 * @param resolveWorkspace - how this host turns a session id into a workspace.
 */
export declare function handleAssetsRequest(req: IncomingMessage, res: ServerResponse, url: URL, resolveWorkspace?: WorkspaceResolver): Promise<void>;
/**
 * Register the asset routes on the host webserver.
 *
 * The workspace resolver reads the session service, so the session id a browser
 * sends is turned into a path by the host rather than trusted from the wire.
 * @param ctx - the plugin context.
 * @returns the disposer removing the routes.
 */
/**
 * The host's session-to-workspace lookup.
 *
 * The session service is read through `ctx.get` rather than injected: a host
 * without sessions (a stripped deployment, a unit test) still serves the mounted
 * library, it just cannot resolve a workspace.
 * @param ctx - the plugin context.
 * @returns the resolver the routes and the facade share.
 */
export declare function workspaceOfSession(ctx: Context, sessionId: string | undefined): string | undefined;
/**
 * The routes' form of {@link workspaceOfSession}.
 * @param ctx - the plugin context.
 * @returns the resolver the routes use.
 */
export declare function sessionWorkspaceResolver(ctx: Context): WorkspaceResolver;
/**
 * Register the asset routes on the host webserver.
 *
 * The workspace resolver reads the session service, so the session id a browser
 * sends is turned into a path by the host rather than trusted from the wire.
 * @param ctx - the plugin context.
 * @returns the disposer removing the routes.
 */
export declare function registerAssetRoutes(ctx: Context): () => void;
//# sourceMappingURL=asset-routes.d.ts.map