/**
 * Dictionaries for the settings section. The plugin follows the browser's
 * language preference through `navigator.language`: the two dictionaries are
 * keyed identically and `t()` picks one, falling back to English for any
 * language the pair does not cover.
 *
 * Deliberately dependency-free — no locale service, no registration order to
 * get right — so a deployment that needs a third language swaps this module,
 * not the section.
 * @module @roubaai/settings/client/locales
 */
/** The dictionary key union: both languages carry exactly these keys. */
declare const zh: {
    readonly intro: "配置图片 / 视频 / 音乐生成服务的提供方。API Key 只写入、不回显。";
    readonly categoryImage: "图片";
    readonly categoryVideo: "视频";
    readonly categoryMusic: "音乐";
    readonly defaultProviderName: "默认";
    readonly customBadge: "自定义";
    readonly activeLabel: "使用中";
    readonly useAction: "使用";
    readonly editAction: "编辑";
    readonly deleteAction: "删除";
    readonly addProvider: "添加自定义提供方";
    readonly apiKeyTitle: "API Key";
    readonly apiKeyDesc: "保存后不再显示";
    readonly apiKeySaved: "已保存，留空表示不修改";
    readonly apiKeyUnset: "尚未设置";
    readonly adapterTitle: "适配器";
    readonly adapterHint: "由哪个已安装的后端处理这一行。可选值来自本次部署实际挂载的插件。";
    readonly baseUrlTitle: "接口地址";
    readonly baseUrlReadonly: "内置默认端点，不可修改。";
    readonly getApiKey: "获取专属 API Key";
    readonly modelTitle: "模型";
    readonly modelDesc: "选项来自该后端当前的模型目录；厂商会更换模型 id，留空则用内置默认值。";
    readonly modelPlaceholder: "输入或选择模型 id";
    readonly modelLoading: "正在读取模型目录…";
    readonly modelEmpty: "目录为空：该后端未返回任何模型，请手工填写模型 id。";
    readonly modelUnsupported: "该后端不支持列出模型，请手工填写模型 id。";
    readonly modelListFailed: "读取模型目录失败：";
    readonly modelRefresh: "刷新目录";
    readonly capTiers: "可用档位";
    readonly capRefs: "参考图上限";
    readonly capRatios: "支持比例";
    readonly capPixelsUnit: "像素";
    readonly tierTitle: "分辨率档位";
    readonly tierDesc: "选项来自该模型自己上报的能力，不同模型的可用档位不同；留空表示跟随默认档位。";
    readonly tierInherit: "跟随默认";
    readonly tierUnsupported: "该档位不在当前模型支持的范围内：";
    readonly tierUnsupportedMark: "（该模型不支持，请改选后再保存）";
    readonly nameTitle: "名称";
    readonly namePlaceholder: "提供方名称";
    readonly cancel: "取消";
    readonly save: "保存";
    readonly saving: "保存中…";
    readonly test: "测试连接";
    readonly testing: "测试中…";
    readonly saveFailed: "保存失败：";
    readonly testFailed: "测试失败：";
    readonly probeUnconfigured: "未配置 API Key";
    readonly conflict: "配置已被其他端修改，请刷新后重试。";
    readonly untitledProvider: "未命名提供方";
};
type MessageKey = keyof typeof zh;
/**
 * Look up one message in the active language.
 * @param key - the dictionary key.
 * @returns the localized string.
 */
export declare function t(key: MessageKey): string;
export {};
//# sourceMappingURL=locales.d.ts.map