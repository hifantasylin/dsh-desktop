/**
 * The Settings page's view of `ctx.media`: which adapters this deployment
 * mounted, and how a row's connectivity probe reaches the adapter that owns it.
 *
 * Both faces are structural rather than an import of `@roubaai/media`, so the
 * configuration package stays independent of any backend package and keeps
 * working on a surface where no media plugin is mounted at all. This module
 * lives beside the route rather than inside it so each half is testable without
 * booting a web server.
 * @module @roubaai/settings/adapters
 */
import type { Context } from '@deepseek-ai/cordis';
import type { AdapterChoice, MediaCategory, ModelsListResult, TestResult } from './shared.ts';
/** Values a probe runs against: the card's draft, an unsaved key included. */
export interface AdapterProbeDraft {
    /** Endpoint base the form shows. */
    baseUrl: string;
    /** API key the form holds. */
    apiKey: string;
    /** Model the form shows, when the category configures one. */
    model?: string;
}
/**
 * The providers this deployment mounted, per category, as display choices. The
 * deployment's own plugin composition — never this package — decides what a row
 * may point at; this only adds the presentation facts.
 * @param ctx - the plugin context (the media service is optional).
 * @returns one choice list per category; every list empty without the service.
 */
export declare function adapterCatalog(ctx: Context): Record<MediaCategory, AdapterChoice[]>;
/**
 * One registry name as a display choice. An adapter this table does not know
 * keeps its own name as the label: showing a raw id is better than inventing a
 * name for a backend whose vendor this package cannot identify.
 * @param name - the registry name the provider registered itself under.
 * @returns the choice the page renders.
 */
export declare function adapterChoice(name: string): AdapterChoice;
/**
 * Run the selected adapter's own probe. Every "cannot" — no adapter named, no
 * media service, an adapter this deployment did not mount, a provider without a
 * probe — returns `undefined` so the caller keeps its generic endpoint probe.
 * @param ctx - the plugin context (the media service is optional).
 * @param category - which category's registry to look the adapter up in.
 * @param adapter - the registry name the row names; empty when unset.
 * @param draft - the values the form shows.
 * @returns the probe's outcome, or `undefined` to fall back.
 */
export declare function probeViaAdapter(ctx: Context, category: MediaCategory, adapter: string, draft: AdapterProbeDraft): Promise<TestResult | undefined>;
/**
 * Read the row's backend model catalogue. The row's adapter owns the call
 * because only it knows its own model-list protocol; the draft's endpoint and
 * key are handed over too, so a catalogue can be browsed — and a key validated
 * — before the form is saved.
 *
 * Three outcomes, never a silent empty list:
 *
 *  - the backend implements no catalogue call → an empty list plus a message,
 *    which is how the form learns to keep its free-text model input;
 *  - the adapter is named but this deployment did not mount it → a thrown
 *    error, since the row cannot be served at all;
 *  - the backend's own call failed → its error propagates verbatim, so a
 *    retired key, a denied model, or an unreachable endpoint stays readable
 *    instead of being flattened into "no models".
 *
 * @param ctx - the plugin context (the media service is optional).
 * @param category - which category's registry to look the adapter up in.
 * @param adapter - the registry name the row names; empty when unset.
 * @param draft - the endpoint and key the form holds (an unsaved key included).
 * @param signal - cancellation forwarded to the catalogue call.
 * @returns the catalogue — each model carrying its capability when its backend
 * states one — or an empty list with the reason it is empty.
 * @throws {Error} when no media service or no such mounted adapter exists.
 */
export declare function modelsViaAdapter(ctx: Context, category: MediaCategory, adapter: string, draft: AdapterProbeDraft, signal?: AbortSignal): Promise<ModelsListResult>;
//# sourceMappingURL=adapters.d.ts.map