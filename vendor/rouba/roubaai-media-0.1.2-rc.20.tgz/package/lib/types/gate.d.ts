/**
 * The generation gate: the single place that decides whether a paid generation
 * may start at all.
 *
 * This is the "who may spend money" boundary, not a lint. It runs before the
 * provider is asked to submit anything, so a refusal costs nothing — which is
 * the whole point: the expensive mistakes (generating an asset the project
 * never planned, generating a shot whose prompt was never reviewed) are caught
 * at the first frame rather than after ten of them.
 *
 * ## Why it lives here and not in a skill
 *
 * A skill can only *ask* the model to follow a process. The model may skip it,
 * misread it, or explain it away — and in the project this design came from, it
 * did all three. A rule the model can talk its way past is not a rule. This
 * function cannot be talked past: `submit` is never reached, so nothing is
 * billed.
 *
 * ## What it deliberately does not do
 *
 * It does not review the prompt's quality, judge the framing, or second-guess a
 * creative decision. It asks whether the work being paid for is work this
 * project planned, reviewed, and laid out for the user to look at — three facts
 * about the project's own files — and leaves everything inside that boundary to
 * the model and the user.
 *
 * @module @roubaai/media/gate
 */
/** The generation kinds the gate guards. */
export type GateKind = 'image' | 'video';
/** One request to spend money, reduced to the facts the gate needs. */
export interface GateRequest {
    /** Which paid tool is being called. */
    readonly kind: GateKind;
    /** The project the work belongs to (`project` tool argument). */
    readonly project?: string | undefined;
    /** The shot or asset identifier (`label` tool argument). */
    readonly label?: string | undefined;
    /** The unit this shot belongs to, when the caller names it outright. */
    readonly unit?: string | undefined;
    /** The writable asset root holding `<project>/` directories. */
    readonly assetsRoot: string;
}
/** The gate's answer. A refusal always carries a reason the model can act on. */
export type GateDecision = {
    readonly allow: true;
    readonly note?: string;
} | {
    readonly allow: false;
    readonly reason: string;
};
/**
 * Every asset id the project's manifest declares.
 *
 * The manifest writes ids two ways — a table row (`| CH001 | 大牙 | …`) and a
 * heading (`### ST001_…`) — so the whole file is scanned for ids rather than
 * one section parsed. A manifest that gains another section keeps working.
 * @param text - the manifest file's contents.
 * @returns the declared ids, upper-cased and deduplicated.
 */
export declare function manifestIds(text: string): ReadonlySet<string>;
/**
 * The asset ids a `label` names. A label is free text (`KF03_格3_奶奶出门`,
 * `EP01_镜02_镇民躲藏`), so this is a scan, not a parse.
 * @param label - the tool call's `label` argument.
 * @returns the named ids, upper-cased and deduplicated.
 */
export declare function labelIds(label: string): readonly string[];
/**
 * The unit a call names: an explicit argument wins, else the label's id.
 *
 * The bounds are lookarounds, not `\b`: a label routinely glues the id to a
 * separator (`U09_厨房空镜`), and `_` is a word character — so a trailing `\b`
 * silently fails to match exactly the labels this is here to read. The same
 * mistake already cost the asset-id scan once.
 */
export declare function unitOf(request: GateRequest): string | undefined;
/**
 * Decide whether one paid generation may start.
 *
 * The gate only refuses when it has something to check against: a project and
 * an asset manifest that both exist, and a `label` naming an id the manifest
 * does not declare. Everything else is allowed and *marked*.
 *
 * That asymmetry is deliberate. Before the asset stage there is no manifest —
 * a style probe at P1 is legitimate work, and refusing it because the project
 * has not planned assets yet would block the start of every project. Refusing
 * on "I cannot tell" would also make the cheapest way past the gate to hand it
 * nothing to read. Marking instead keeps the decision visible without
 * pretending the gate knows something it does not.
 *
 * The refusal that matters is the one it can actually make: the project HAS a
 * plan, and this generation is not in it.
 * @param request - the facts the gate needs about one paid call.
 * @returns whether the call may proceed, and why not when it may not.
 */
export declare function checkGate(request: GateRequest): Promise<GateDecision>;
//# sourceMappingURL=gate.d.ts.map