/**
 * `generate_image` tool: text-to-image / reference-image edit via a configured
 * media provider, run as a `ctx.jobs` background task. Image generation takes
 * tens of seconds to minutes (Maizi's synchronous endpoint blocks until the
 * server has generated the image), so the foreground `execute` only starts the
 * job and returns the id — it never blocks on the provider call. The model
 * reads the full result (attachment reference + 24h result URL) through
 * `job_output`; no completion message is pushed into the session, which would
 * otherwise pile up as queued messages and force extra model turns.
 *
 * Per-model capability is the single source of truth for what a call may ask
 * for. The resolution parameter carries NO enum: the tiers a model accepts
 * differ per generation (and per vendor release), so a list written here would
 * be a second copy of a fact the backend already owns — and it drifted exactly
 * that way, advertising a tier the configured model did not have. Instead the
 * call is validated at tool-call time against the serving provider's own
 * `capabilities()`, and a tier the configured model cannot produce is either
 * served by a sibling model that can (the result says so) or refused with a
 * message naming the model, its tiers, and its pixel floor.
 *
 * @module @roubaai/media/tools/generate-image
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "generate_image";
export declare function registerGenerateImage(ctx: Context): () => void;
//# sourceMappingURL=generate-image.d.ts.map