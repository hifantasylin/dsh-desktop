import type { HeroBrandMarkOwnerProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { SidebarBrandMarkOwnerProps } from '@deepseek-ai/dsh-client-ui-sidebar/client';
type RoubaBrandMarkProps = HeroBrandMarkOwnerProps & SidebarBrandMarkOwnerProps;
/**
 * Render the RoubaAI mark with the presentation requested by its host surface.
 *
 * The artwork is a square tile rather than a transparent glyph, so it is drawn
 * as a rounded badge at the requested edge instead of inheriting `currentColor`
 * the way the fish mark it replaced did. It carries no accessible name: like the
 * mark before it, it is decorative and the wordmark beside it names the product.
 * @param props - Host-supplied mark presentation.
 * @returns the RoubaAI mark.
 */
export declare function RoubaBrandMark({ size, className }: RoubaBrandMarkProps): import("react").JSX.Element;
/**
 * Render the Rouba name artwork without its independently slotted mark.
 * @returns the "Rouba DSH" name wordmark.
 */
export declare function RoubaBrandName(): import("react").JSX.Element;
export {};
//# sourceMappingURL=Brand.d.ts.map