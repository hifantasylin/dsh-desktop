/**
 * Sidebar icon for the canvas tab: a framed surface holding two connected
 * nodes — the thing the canvas is for.
 * @module @roubaai/canvas/client/canvas-panel-icon
 */
import type { JSX } from 'react';
/**
 * Render the tab's icon.
 * @param props - requested square edge in pixels.
 * @returns the icon, drawn in the surrounding control's color.
 */
export declare function CanvasPanelIcon({ size }: {
    size: number;
}): JSX.Element;
//# sourceMappingURL=canvas-panel-icon.d.ts.map