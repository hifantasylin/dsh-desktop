/**
 * Client half of `@roubaai/canvas`: the canvas as a right-sidebar tab.
 *
 * The shell's right column belongs to the sidebar plugin, which exposes a
 * registration service for exactly this: a tab type of our own, listed in its
 * "new tab" menu and openable by any code that holds the service. The canvas
 * therefore reaches the user two ways, and both land in the same tab:
 *
 * - the menu entry, for when the user goes looking;
 * - a canvas link in the conversation, which this half takes over and turns
 *   into that same open, so the workbench opens beside the chat instead of in
 *   a browser window.
 *
 * Registering the type and taking over the clicks are one decision split in
 * two: both name {@link TAB_ID}, and a link that opened something else would be
 * a defect no other check would catch.
 *
 * The canvas itself stays a served app under the host's mount point; this half
 * owns only the panel around it. `inject` waits for the sidebar service, so a
 * deployment without that plugin simply has no in-app canvas surface — the
 * route under the mount point is unaffected.
 * @module @roubaai/canvas/client
 */
import type { Context } from '@deepseek-ai/cordis';
/** The sidebar service must be up before a tab can be contributed. */
export declare const inject: string[];
/**
 * Register the canvas tab and take over canvas links.
 * @param ctx - the client cordis context carrying the sidebar service.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map