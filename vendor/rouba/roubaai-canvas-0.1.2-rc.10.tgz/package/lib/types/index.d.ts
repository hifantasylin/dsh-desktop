/**
 * `@roubaai/canvas` — the canvas workbench's host half.
 *
 * The canvas is a browser app; making it useful from the harness means serving it
 * from the harness origin, so its pages can call the media routes as same-origin
 * requests. This plugin does exactly that and nothing else: no DOM patching, no
 * second process, no injected sidebar entry.
 *
 * What it serves, all under `basePath` (default `/canvas`):
 * - the built frontend from `canvasRoot`, with an SPA fallback to `index.html`;
 * - `/plugins/index.json` — the local node-plugin manifest the canvas discovers
 *   on startup — listing the asset-library node this package ships;
 * - `/plugins/roubaai-assets.js` — that node plugin.
 *
 * It also serves one route outside the mount point, under `panelInfoPath`
 * (default `/api/roubaai-canvas`): `GET <panelInfoPath>/panel` answers the
 * resolved mount point. The client half embeds the canvas in an iframe and
 * cannot read the composition's configuration, so this is how the panel finds
 * an app mounted somewhere other than `/canvas`.
 *
 * `canvasRoot` must be a build made with a matching `VITE_BASE` (the frontend
 * references its bundle as `/assets/...`, so a build for `/` cannot be served
 * under `/canvas/`). The build shipped inside this package — `frontend/`, filled
 * by `scripts/sync-frontend.mjs` before packing — is what a plain install serves,
 * so a composition needs no configuration and carries no path from the machine
 * that packaged it. `canvasRoot` overrides that, which is how a development
 * checkout serves the build it is iterating on. When neither exists the route
 * answers a plain explanation instead of pretending to be an app.
 *
 * @module @roubaai/canvas
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "roubaai-canvas";
/** The webserver service must be up before the routes can mount. */
export declare const inject: string[];
/** The frontend build shipped inside this package, beside `lib/`. */
export declare function bundledCanvasRoot(): string;
/** The directory a composition ended up serving, and how it got there. */
export interface CanvasRootChoice {
    /** The directory to serve, or `''` when there is no frontend at all. */
    readonly root: string;
    /** `configured` for an override that exists, `bundled` for the shipped build. */
    readonly source: 'configured' | 'bundled' | 'missing';
    /** The resolved `canvasRoot` the composition asked for, when it asked for one. */
    readonly requested: string;
}
/**
 * Decide which frontend directory to serve.
 *
 * A configured root wins while it actually holds an `index.html`, so a
 * development checkout keeps serving the build it is iterating on. Otherwise the
 * build shipped in this package is served, which is what makes a plain install
 * work with no configuration and no path from the packaging machine.
 * @param configured - the composition's `canvasRoot`, if it set one.
 * @param bundled - the shipped frontend directory; overridden in tests.
 * @param hasIndex - the existence probe; overridden in tests.
 * @returns the chosen directory, why it was chosen, and what was asked for.
 */
export declare function pickCanvasRoot(configured: string | undefined, bundled?: string, hasIndex?: (directory: string) => boolean): CanvasRootChoice;
/** Configuration the composition supplies for this plugin. */
export interface CanvasConfig {
    /**
     * Built frontend directory (`VITE_BASE` must match {@link CanvasConfig.basePath}).
     * Omit it to serve the build shipped inside this package.
     */
    readonly canvasRoot?: string;
    /** Mount point; defaults to `/canvas`. */
    readonly basePath?: string;
    /**
     * The generation facade's path on this origin, published to the canvas through
     * `config.js`. Defaults to the media plugin's OpenAI-compatible facade.
     */
    readonly openaiBasePath?: string;
    /**
     * Where the in-app panel reads the resolved mount point; the route is
     * `<panelInfoPath>/panel`. Defaults to `/api/roubaai-canvas`.
     */
    readonly panelInfoPath?: string;
}
/**
 * Resolve a request path inside the frontend directory.
 * @param root - the built frontend directory.
 * @param relative - the request path below the mount point.
 * @returns the absolute file path, or undefined when it escapes the root.
 */
export declare function resolveCanvasFile(root: string, relative: string): string | undefined;
/**
 * Answer one canvas request.
 * @param req - the incoming request.
 * @param res - the response to write.
 * @param url - the parsed request URL.
 * @param config - the resolved configuration.
 */
export declare function handleCanvasRequest(req: IncomingMessage, res: ServerResponse, url: URL, config: {
    basePath: string;
    canvasRoot: string;
    requestedCanvasRoot?: string;
    openaiBasePath: string;
}): Promise<void>;
/**
 * Answer the in-app panel's runtime-path request.
 *
 * The panel embeds the canvas in an iframe and runs in the shell's browser
 * context, where the composition's configuration is not readable: hardcoding
 * `/canvas` there would break a deployment that moved the app.
 * @param req - the incoming request.
 * @param res - the response to write.
 * @param info - the resolved mount point.
 */
export declare function handlePanelInfoRequest(req: IncomingMessage, res: ServerResponse, info: {
    basePath: string;
}): void;
/**
 * Register the canvas routes on the host webserver.
 * @param ctx - the plugin context.
 * @param config - the composition's configuration for this plugin.
 */
export declare function apply(ctx: Context, config?: CanvasConfig): void;
declare const _default: {
    name: string;
    inject: string[];
    apply: typeof apply;
};
export default _default;
//# sourceMappingURL=index.d.ts.map