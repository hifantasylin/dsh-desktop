/**
 * Key resolution for both Ark providers, in one place so the image and video
 * backends can never disagree about where a key comes from.
 *
 * The order is deliberate and identical to every other backend in this family:
 * the value a person just typed into the form (it is the most recent statement
 * of intent, and it is what lets a key be validated before it is stored), then
 * the stored Settings row, then the credential store — and through it the
 * `apiKeyEnv` environment variable.
 *
 * The `undefined` return is the interesting part: it is what lets a caller tell
 * "this deployment has no key configured" (a neutral state to show, not a
 * failure) from "a key exists and the backend refused it" (a real failure that
 * needs the vendor's reason).
 * @module @roubaai/media-ark/credentials
 */
import type { Context } from '@deepseek-ai/cordis';
import type { MediaSettingsCategory } from '@roubaai/media';
/**
 * Resolve the key an operation should use, or `undefined` when none exists.
 * @param ctx - the plugin context (the credential store is optional).
 * @param namespace - the settings namespace the Settings page owns.
 * @param category - which category's active row to read the stored key from.
 * @param apiKeyEnv - the credential reference consulted as the last resort.
 * @param draftKey - a key the configuration form holds but has not saved.
 * @returns the key to present, or `undefined` when nothing is configured.
 */
export declare function resolveArkKey(ctx: Context, namespace: string, category: MediaSettingsCategory, apiKeyEnv: string, draftKey?: string): Promise<string | undefined>;
/**
 * The reason fragment an `unconfigured` probe reports: which sources were
 * consulted and found empty, so the reader knows what to fill in.
 * @param apiKeyEnv - the credential reference that was also consulted.
 * @returns the fragment, meant to follow a "no API key configured" label.
 */
export declare function arkUnconfiguredReason(apiKeyEnv: string): string;
//# sourceMappingURL=credentials.d.ts.map