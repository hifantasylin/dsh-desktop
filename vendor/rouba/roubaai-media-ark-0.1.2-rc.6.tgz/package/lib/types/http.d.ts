/**
 * Minimal JSON and result-probe HTTP helper for the Ark adapter, over the
 * global `fetch` (Node's undici). Only the calls this provider makes: create a
 * generation task, poll it, and confirm the produced file is reachable.
 *
 * No third-party runtime dependency: `fetch` is a Node >= 22 global.
 * @module @roubaai/media-ark/http
 */
/** Raised for an Ark HTTP failure carrying the status and a bounded body snippet. */
export declare class ArkHttpError extends Error {
    readonly status: number | undefined;
    constructor(message: string, status?: number);
}
/**
 * Raised for a transport-level failure (DNS, connect, TLS, socket reset) after
 * the retry loop is exhausted. The message always names the stage that failed,
 * so a caller can tell "the provider rejected the request" from "the network
 * dropped before we could ask".
 */
export declare class ArkNetworkError extends Error {
    constructor(message: string, cause?: unknown);
}
/** Whether an error is a transport-level failure rather than an HTTP answer. */
export declare function isNetworkError(error: unknown): error is ArkNetworkError;
/**
 * Human meaning for the Ark status codes a caller is most likely to act on.
 * Kept to one line each so a job detail stays a single readable line.
 * @param status - the HTTP status, when one was received.
 * @returns the meaning, or a generic rendering.
 */
export declare function arkStatusMeaning(status: number | undefined): string;
/** Render `[status] meaning` when a status is present, else the bare message. */
export declare function statusTag(error: unknown): string;
/** The vendor's own explanation of a refusal, as Ark nests it in an error body. */
export interface ArkErrorDetail {
    /** Ark's machine-readable code, e.g. `InvalidEndpointOrModel.NotFound`. */
    code?: string;
    /** Ark's human-readable explanation, verbatim (Chinese in the cn region). */
    message?: string;
}
/**
 * Pull `error.code` / `error.message` out of an Ark error body. Ark is the only
 * authority on why it refused a request, and for a retired model id its code is
 * the whole diagnosis — a generic status mapping would report it as a missing
 * task, which sends a caller looking in the wrong place.
 * @param data - the parsed response body (untrusted).
 * @returns the fields Ark stated, each absent when it stated none.
 */
export declare function arkErrorDetail(data: unknown): ArkErrorDetail;
/** Whether an Ark refusal names a model id or endpoint Ark no longer serves. */
export declare function isModelNotFound(status: number | undefined, detail: ArkErrorDetail): boolean;
/** Request headers: JSON content type plus the Ark bearer credential. */
export declare function arkHeaders(apiKey: string): Record<string, string>;
/**
 * POST a JSON body and parse the JSON response, retrying transient failures
 * (network errors and 5xx). A 4xx returns the status without retrying so Ark's
 * own validation errors surface immediately.
 * @param url - the absolute endpoint.
 * @param apiKey - the Ark API key to present.
 * @param body - the JSON-serializable request body.
 * @param signal - cancellation forwarded to `fetch`.
 * @returns the status and parsed body.
 */
export declare function postJson(url: string, apiKey: string, body: unknown, signal?: AbortSignal): Promise<{
    status: number;
    data: unknown;
}>;
/**
 * GET a JSON response, retrying transient failures. Used to poll task state.
 * @param url - the absolute endpoint.
 * @param apiKey - the Ark API key to present.
 * @param signal - cancellation forwarded to `fetch`.
 * @returns the status and parsed body.
 */
export declare function getJson(url: string, apiKey: string, signal?: AbortSignal): Promise<{
    status: number;
    data: unknown;
}>;
/** What a result-URL probe reports: reachability, plus the size when stated. */
export interface ResultProbe {
    status: number;
    /** Total byte size from `content-length`, when the CDN states one. */
    sizeBytes?: number;
}
/**
 * Confirm a produced file is reachable and read its stated size, then cancel
 * the body: the bytes themselves flow through the host's media proxy when the
 * user plays or downloads the asset, so holding them here would only buffer a
 * whole video for a `content-length` header.
 * @param url - the result URL to probe.
 * @param signal - cancellation forwarded to `fetch`.
 * @returns the probe outcome, or `undefined` when the upstream produced no body.
 */
export declare function probeResult(url: string, signal?: AbortSignal): Promise<ResultProbe | undefined>;
/** Download options: size bounds and an inactivity timeout. */
export interface DownloadOptions {
    /** Refuse a response body larger than this many bytes. */
    maxBytes?: number;
    /** Require the downloaded body to be at least this many bytes (catches truncated downloads). */
    minBytes?: number;
    /** Inactivity (no chunk received) timeout in ms; resets on each chunk. */
    inactivityTimeoutMs?: number;
    /**
     * Optional progress callback fired on each received chunk with the running
     * received byte count and the total expected bytes (from `content-length`,
     * which may be absent). Lets a caller surface real download progress.
     */
    onProgress?: (receivedBytes: number, totalBytes: number | undefined) => void;
}
/**
 * Download a URL into raw bytes (a generated image, before it is handed to the
 * attachment store), streaming the body and verifying size bounds, with
 * transient-failure retry. The caller owns `maxBytes`; providers pass
 * `minBytes` and an inactivity timeout so a truncated download is retried
 * rather than landed as a corrupt file.
 * @param url - the result URL to fetch.
 * @param signal - cancellation forwarded to `fetch`.
 * @param options - size bounds, inactivity timeout, and the progress callback.
 * @returns the complete body bytes.
 * @throws {ArkHttpError} on a non-2xx answer or a violated size bound.
 * @throws {ArkNetworkError} when the transport fails after every retry.
 */
export declare function downloadBytes(url: string, signal?: AbortSignal, options?: DownloadOptions): Promise<Uint8Array>;
//# sourceMappingURL=http.d.ts.map