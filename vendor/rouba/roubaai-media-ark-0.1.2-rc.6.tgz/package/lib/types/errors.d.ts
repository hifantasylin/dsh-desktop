/**
 * The error one Ark provider raises when it cannot find a key anywhere. Shared
 * by the image and video providers so a caller's `instanceof` check holds
 * whichever Ark backend it reached, and so both report the same reference.
 * @module @roubaai/media-ark/errors
 */
/** Raised when neither the Settings page nor the credential store holds a key. */
export declare class MissingCredentialError extends Error {
    readonly code = "MISSING_CREDENTIAL";
    constructor(reference: string);
}
//# sourceMappingURL=errors.d.ts.map