/**
 * Ark's model catalogue: the read side of `GET {base}/models`, shared by the
 * video and image providers because both need the same two things — a live list
 * of what may be requested, and a recovery hint to attach when Ark refuses a
 * model id it no longer serves.
 *
 * Model ids are the reason this module exists at all. Ark ids embed a release
 * or date segment (`doubao-seedance-2-0-260128`, `doubao-seedream-5-0-pro-260628`)
 * and Ark retires them on its own schedule, so a hardcoded id is a promise the
 * vendor never made. Asking Ark is the only sound answer, and it is also what
 * turns an opaque `InvalidEndpointOrModel.NotFound` into a usable next step.
 * @module @roubaai/media-ark/ark-models
 */
import type { MediaModelInfo } from '@roubaai/media';
/** Which entries of the catalogue one caller wants. */
export interface ArkModelFilter {
    /** Keep an entry whose `task_type` contains this fragment (e.g. `Video`). */
    taskType?: string;
    /** Keep an entry whose id contains this fragment (e.g. `seedream`). */
    idIncludes?: string;
}
/**
 * Parse the `GET /models` payload into the seam's model list. The endpoint
 * answers `{ object: 'list', data: [...] }`; a bare array is accepted too, since
 * a gateway in front of Ark may unwrap it. An entry without a usable id is
 * dropped rather than surfaced as an unrequestable row.
 * @param data - the parsed response body (untrusted).
 * @returns one entry per model Ark reported, in Ark's own order.
 */
export declare function parseArkModels(data: unknown): MediaModelInfo[];
/**
 * Keep the entries one provider can actually serve. An entry Ark reports
 * without a `task_type` is kept when only an id fragment is asked for, and
 * dropped when a capability is asked for — an unlabelled row cannot be shown to
 * be the kind wanted, and offering it would send a request Ark rejects.
 * @param models - the parsed catalogue.
 * @param filter - which entries to keep; an empty filter keeps everything.
 * @returns the matching entries, in input order.
 */
export declare function filterArkModels(models: readonly MediaModelInfo[], filter: ArkModelFilter): MediaModelInfo[];
/**
 * Fetch and filter Ark's catalogue. A non-200 is raised rather than swallowed:
 * "the backend could not be asked" must stay distinguishable from "the backend
 * offers nothing".
 * @param baseUrl - the resolved endpoint base (no trailing slash).
 * @param apiKey - the Ark API key to present.
 * @param filter - which entries to keep.
 * @param signal - cancellation forwarded to the request.
 * @returns the matching models.
 * @throws {ArkHttpError} when Ark answers a non-200.
 */
export declare function fetchArkModels(baseUrl: string, apiKey: string, filter: ArkModelFilter, signal?: AbortSignal): Promise<MediaModelInfo[]>;
/**
 * Render model ids as the one-line hint an error message carries, e.g.
 * `doubao-seedance-2-0-mini-260615、doubao-seedance-2-0-260128`.
 * @param models - the available models.
 * @returns the ids joined with an ideographic comma, or `''` when there are none.
 */
export declare function formatModelIds(models: readonly MediaModelInfo[]): string;
//# sourceMappingURL=ark-models.d.ts.map