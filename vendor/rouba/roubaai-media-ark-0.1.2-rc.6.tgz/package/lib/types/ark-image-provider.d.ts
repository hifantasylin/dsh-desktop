/**
 * Volcengine Ark image provider — the vendor's synchronous image API
 * (`POST {base}/images/generations`, Seedream models).
 *
 * This adapter calls Ark directly with a deployment's own `ARK_API_KEY`, so a
 * deployment can run Seedream without routing through an aggregator. The seam's
 * provider-neutral input maps onto Ark's flat body here: `refImages` becomes the
 * `image` field (one reference as a bare string, several as an array), and the
 * requested geometry becomes either an explicit `WxH` pixel size — looked up in
 * Ark's documented per-generation table — or the resolution tier string Ark
 * accepts on its own.
 *
 * Ark model ids embed a release/date segment and retire, so nothing here
 * hardcodes one beyond the configurable default: {@link ArkImageProvider.listModels}
 * asks the backend what it serves, and a submission refused for an unknown id
 * reports that list instead of a generic failure.
 *
 * Per-model capability lives in ONE table here ({@link IMAGE_GENERATIONS}),
 * which {@link ArkImageProvider.capabilities} hands to the tool and the
 * Settings page. Everything a request may name — resolution tiers, the pixel
 * floor, the reference bound — is read from it, so a vendor tier change is a
 * one-line edit rather than a hunt for the second copy of the fact.
 *
 * Ark prices in RMB with vendor-specific discounts and tiers, so this adapter
 * reports no USD estimate — the ledger records the run unpriced rather than
 * converting at a rate this package does not own.
 * @module @roubaai/media-ark/ark-image-provider
 */
import type { Context } from '@deepseek-ai/cordis';
import { ImageProvider } from '@roubaai/media';
import type { ImageCaps, ImageGenerationResult, ImageGenerateInput, MediaModelCapability, MediaModelInfo, MediaProgress, ProviderProbeDraft, ProviderProbeResult } from '@roubaai/media';
export { MissingCredentialError } from './errors.ts';
/** Credential reference for the Ark API key (shared with the video provider). */
export declare const ARK_API_KEY_REF = "ARK_API_KEY";
/**
 * Fallback image model, Ark's plain (non-"pro") Seedream 5.0 id — the lite
 * class. It is the default because it is the tier this deployment runs for
 * ordinary work and the one whose bounds are widest (2K through 4K); a request
 * that needs a tier only the pro sibling serves is moved there automatically by
 * the tool. Ark re-dates these ids between releases, so this is a default to
 * start from, never a guarantee: `listModels()` reports what the deployment may
 * actually request.
 */
export declare const DEFAULT_IMAGE_MODEL = "doubao-seedream-5-0-260128";
/** Ark's public API base (cn-beijing region). */
export declare const ARK_IMAGE_BASE_URL = "https://ark.cn-beijing.volces.com/api/v3";
/** Provider config; every field is optional with a sensible default. */
export interface ArkImageConfig {
    /** Endpoint base; defaults to {@link ARK_IMAGE_BASE_URL}. */
    baseUrl?: string;
    /** Default model id; defaults to {@link DEFAULT_IMAGE_MODEL}. */
    model?: string;
    /** Credential reference (environment-variable name); defaults to `ARK_API_KEY`. */
    apiKeyEnv?: string;
    /**
     * Settings namespace the roubaai Settings page owns. The key, endpoint, and
     * model a user stores there win over this config; they are read per
     * operation, so editing the page takes effect without reloading the plugin.
     */
    settingsNamespace?: string;
}
/**
 * Volcengine Ark image provider (Seedream). Generation is synchronous; the
 * produced image is downloaded and landed through `ctx.attachments.saveImage`,
 * with a URL-only degradation when the download fails — the image already
 * exists at that point, so the job must not fail or regenerate it.
 */
export declare class ArkImageProvider extends ImageProvider {
    private readonly ctx;
    readonly provider = "ark";
    readonly defaultModel: string;
    private readonly baseUrl;
    private readonly apiKeyEnv;
    private readonly settingsNamespace;
    constructor(ctx: Context, config?: ArkImageConfig);
    /**
     * Resolve the API key per operation. The Settings page wins over the
     * credential store: it is the deployment's explicit per-install choice and
     * the one surface a person can edit without touching the environment. The
     * credential store — and through it `ARK_API_KEY` — stays the fallback, so a
     * deployment that never opens the Settings page is unaffected.
     * @returns the resolved key.
     * @throws {MissingCredentialError} when no source holds a key.
     */
    private resolveKey;
    /**
     * The key a probe should present, or `undefined` when this deployment has
     * none anywhere. `undefined` is not an error here: it is the whole difference
     * between "nothing is configured yet" and "the backend refused what we sent".
     * @param draftKey - a key the configuration form holds but has not saved.
     * @returns the key to present, or `undefined` when nothing is configured.
     */
    private probeKey;
    /**
     * Endpoint base: the Settings page's override when one is stored, else the
     * deployment-configured base. A trailing slash is trimmed so a pasted URL
     * cannot produce a `//` path segment.
     */
    private resolveBaseUrl;
    /**
     * Default image model: the Settings page's override when one is stored, else
     * the deployment-configured model. It is the fallback for a request that
     * names no model; an explicit `input.model` (the tool's sibling substitution)
     * wins over it, which is why the value is re-read per operation.
     */
    private resolveModel;
    generate(input: ImageGenerateInput, signal?: AbortSignal, onProgress?: (progress: MediaProgress) => void): Promise<ImageGenerationResult>;
    /**
     * Refuse a resolved size below the model's documented pixel floor BEFORE the
     * request is submitted. Ark refuses such a size itself ("image size must be
     * at least 3686400 pixels"), but by then the call has been made; the floor is
     * part of the same per-generation table the size was resolved from, so
     * checking it here is exact rather than a guess. A bare tier string — no
     * ratio, or a ratio the table carries no cell for — states no pixel count and
     * is left to Ark to resolve.
     * @param model - the model the request names.
     * @param size - the `size` value about to be sent.
     * @throws {ArkHttpError} when the size is under the model's floor.
     */
    private assertSizeWithinFloor;
    /**
     * Compose the failure message for a refused submission. Ark's own
     * `error.message` is always included — it is the only authoritative reason —
     * and a refusal naming a model id or endpoint it no longer serves is followed
     * by the ids it does serve, because "the model you configured was retired" is
     * otherwise indistinguishable from a bad key or a broken endpoint.
     * @param status - the HTTP status Ark answered.
     * @param data - the parsed error body.
     * @param signal - cancellation forwarded to the model-list request.
     * @returns the one-line message, a failed model lookup included as a hint.
     */
    private submitFailureMessage;
    /**
     * The available-model hint appended to a model-not-found failure. Every
     * failure on this path is swallowed: the model list is a courtesy, and a
     * lookup that fails must never replace the real refusal.
     * @param signal - cancellation forwarded to the model-list request.
     * @returns a `可用模型：…` line, or why the list could not be read.
     */
    private availableModelHint;
    /** Download a generated image, reporting download progress. */
    private downloadResult;
    /**
     * Degrade a generated-but-not-landed image to a URL-only reference. The model
     * and the run echo are passed in (never re-resolved) so the reported
     * `providerMeta` and `run` name the model and tier this generation actually
     * used.
     */
    private urlRef;
    /** Persist image bytes and return the unified result reference. */
    private land;
    /**
     * What one Seedream model accepts, straight out of the same per-generation
     * table the request builder reads — one source for the tiers a request may
     * name, the pixel floor Ark enforces, and the reference bound. The tool
     * validates against it at call time; the Settings page renders it.
     * @param model - the model to describe; omitted describes the model this
     * provider is currently configured to run (its Settings-page row, else its
     * own default).
     * @returns the descriptor, or `undefined` for an id this adapter cannot place
     * (the tool then passes the request through untouched).
     */
    capabilities(model?: string): MediaModelCapability | undefined;
    /** Reference images the model's generation accepts on one image request. */
    caps(model?: string): ImageCaps;
    /**
     * Ark bills in RMB, so this adapter states no USD figure; the ledger records
     * the run unpriced instead of converting at a rate it does not own.
     * @returns always `undefined`.
     */
    estimateCostUsd(): number | undefined;
    /**
     * List the Seedream image models this deployment may request. Ark reports the
     * capability per model as `task_type`, so the catalogue is filtered on it
     * rather than on a naming guess alone.
     * @param signal - cancellation forwarded to the model-list request.
     * @returns the image models Ark reports, in Ark's order.
     * @throws {ArkHttpError} when Ark answers a non-200.
     */
    listModels(signal?: AbortSignal): Promise<MediaModelInfo[]>;
    /**
     * List the image models for the endpoint and key a configuration form holds,
     * so a key that has not been saved yet can still browse the catalogue. An
     * empty draft field falls back to the configured value, exactly as
     * {@link probe} does.
     * @param draft - the endpoint and key the form holds.
     * @param signal - cancellation forwarded to the model-list request.
     * @returns the image models Ark reports, in Ark's order.
     */
    listModelsWithDraft(draft: ProviderProbeDraft, signal?: AbortSignal): Promise<MediaModelInfo[]>;
    /**
     * Probe the endpoint and key the configuration form holds. A model-list read:
     * HTTP 200 proves both reachability and key acceptance without generating
     * anything, and a refusal carries Ark's own status and `error.message` so the
     * form can show what Ark actually said.
     *
     * A row with no key anywhere is reported as `unconfigured`, not as a failure:
     * nothing was probed, and painting that red would hide the difference between
     * "fill this in" and "what you filled in is wrong".
     */
    probe(draft: ProviderProbeDraft): Promise<ProviderProbeResult>;
    testConnection(): Promise<boolean>;
}
//# sourceMappingURL=ark-image-provider.d.ts.map